import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import axios from 'axios';
import ProfilePage from '../components/ProfilePage';

jest.mock('axios');

describe('ProfilePage', () => {
  const mockUserData = {
    name: 'John Doe',
    email: 'john.doe@example.com',
    passportNumber: '123456789',
    visaStatus: 'Approved',
  };

  beforeEach(() => {
    axios.get.mockResolvedValue({ data: mockUserData });
    axios.put.mockResolvedValue({ data: mockUserData });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('loads and displays user data', async () => {
    render(<ProfilePage />);

    await waitFor(() => {
      expect(screen.getByLabelText(/name/i)).toHaveValue(mockUserData.name);
      expect(screen.getByLabelText(/email/i)).toHaveValue(mockUserData.email);
      expect(screen.getByLabelText(/passport number/i)).toHaveValue(mockUserData.passportNumber);
      expect(screen.getByLabelText(/visa status/i)).toHaveValue(mockUserData.visaStatus);
    });
  });

  test('updates user data', async () => {
    render(<ProfilePage />);

    const nameInput = screen.getByLabelText(/name/i);
    const emailInput = screen.getByLabelText(/email/i);
    const passportNumberInput = screen.getByLabelText(/passport number/i);
    const form = screen.getByRole('form');

    fireEvent.change(nameInput, { target: { value: 'Jane Doe' } });
    fireEvent.change(emailInput, { target: { value: 'jane.doe@example.com' } });
    fireEvent.change(passportNumberInput, { target: { value: '987654321' } });

    fireEvent.submit(form);

    await waitFor(() => {
      expect(axios.put).toHaveBeenCalledWith('/api/profile', {
        name: 'Jane Doe',
        email: 'jane.doe@example.com',
        passportNumber: '987654321',
        visaStatus: 'Approved', // Should remain unchanged as it's disabled in the form
      });

      expect(screen.getByLabelText(/name/i)).toHaveValue('Jane Doe');
      expect(screen.getByLabelText(/email/i)).toHaveValue('jane.doe@example.com');
      expect(screen.getByLabelText(/passport number/i)).toHaveValue('987654321');
    });
  });

  test('handles API error gracefully', async () => {
    axios.get.mockRejectedValue(new Error('API Error'));

    render(<ProfilePage />);

    await waitFor(() => {
      expect(screen.getByLabelText(/name/i)).toHaveValue('');
      expect(screen.getByLabelText(/email/i)).toHaveValue('');
      expect(screen.getByLabelText(/passport number/i)).toHaveValue('');
      expect(screen.getByLabelText(/visa status/i)).toHaveValue('');
    });

    expect(screen.getByText(/user profile/i)).toBeInTheDocument();
  });
});
