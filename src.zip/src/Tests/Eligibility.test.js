import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Eligibility from '../components/Eligibility';

describe('Eligibility Component', () => {
  test('renders Eligibility form with all required fields', () => {
    render(<Eligibility />);

    // Check if the main elements are rendered
    expect(screen.getByText('Check Your Visa Eligibility')).toBeInTheDocument();
    expect(screen.getByText('Find out if you are eligible to apply for a visa.')).toBeInTheDocument();

    // Check if the form fields are rendered
    expect(screen.getByLabelText('Full Name:')).toBeInTheDocument();
    expect(screen.getByLabelText('Date of Birth:')).toBeInTheDocument();
    expect(screen.getByLabelText('Country of Citizenship:')).toBeInTheDocument();
    expect(screen.getByLabelText('Country of Destination:')).toBeInTheDocument();
    expect(screen.getByLabelText('Purpose of Visit:')).toBeInTheDocument();
    expect(screen.getByLabelText('Intended Duration of Stay:')).toBeInTheDocument();
    expect(screen.getByLabelText('Previous Visits in this country:')).toBeInTheDocument();
    expect(screen.getByLabelText('Criminal Record:')).toBeInTheDocument();
    expect(screen.getByLabelText('Medical Conditions:')).toBeInTheDocument();
    expect(screen.getByLabelText('Employment Status:')).toBeInTheDocument();
    expect(screen.getByLabelText('Annual Income:')).toBeInTheDocument();

    // Check if the submit button is rendered
    expect(screen.getByText('Check Eligibility')).toBeInTheDocument();
  });
});
