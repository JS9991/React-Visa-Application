import React from 'react';
import profile from '../media/profile.webp';

function Home() {
  return (
    <main>
      <section className="welcome">
        <h1>Welcome, [Applicant Name]!</h1>
        <div className="summary-cards">
          <div className="card">Applications Submitted: [Number]</div>
          <div className="card">Applications in Progress: [Number]</div>
          <div className="card">Notifications: [Number]</div>
        </div>
      </section>
      <section className="quick-actions">
        <button>Start New Application</button>
        <button>Upload Documents</button>
        <button>Check Application Status</button>
      </section>
      <section className="application-status">
        <h2>Application Status Overview</h2>
        <table>
          <thead>
            <tr>
              <th>Application ID</th>
              <th>Type of Visa</th>
              <th>Date Submitted</th>
              <th>Current Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          
          </tbody>
        </table>
      </section>
      <section className="notifications">
        <h2>Recent Notifications</h2>
        <ul>
         
        </ul>
      </section>
      <section className="profile-summary">
        <img src={profile} alt="Profile Picture" className="profile-picture" />
        <div className="personal-details">
          <p>Name: [Applicant Name]</p>
          <p>Email: [Email]</p>
          <p>Phone: [Phone Number]</p>
        </div>
        <button>Edit Profile</button>
      </section>
    </main>
  );
}

export default Home;
