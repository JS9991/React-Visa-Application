const db = require('../db');

class Application {
  static async create(data) {
    const {
      fullName, email, phone, passportNumber, travelDate, purposeOfVisit
    } = data;
    const res = await db.query(
      `INSERT INTO applications (full_name, email, phone, passport_number, travel_date, purpose_of_visit)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [fullName, email, phone, passportNumber, travelDate, purposeOfVisit]
    );
    return res.rows[0];
  }
}

module.exports = Application;
