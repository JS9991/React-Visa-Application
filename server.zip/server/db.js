const { Sequelize, DataTypes } = require('sequelize');
const path = require('path');


const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, 'database.sqlite'),
});


const User = sequelize.define('User', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false,
  }
}, {
  tableName: 'users',
  timestamps: false, 
});


sequelize.sync().then(() => {
  console.log('Database synchronized and tables created.');
}).catch(err => {
  console.error('Error syncing database', err.message);
});


module.exports = {
  sequelize,
  User,
};
