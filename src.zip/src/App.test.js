import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import App from './App';

test('renders the app with all components', () => {
  // Render the App component inside a Router
  render(
    <Router>
      <App />
    </Router>
  );

  // Check if Header component is rendered
  expect(screen.getByText(/header text/i)).toBeInTheDocument();

  // Check if Footer component is rendered
  expect(screen.getByText(/footer text/i)).toBeInTheDocument();

  // Check if Aside component is rendered
  expect(screen.getByText(/aside text/i)).toBeInTheDocument();

  // Check if Routes are working (just a basic check for now)
  expect(screen.getByText(/home/i)).toBeInTheDocument();
  expect(screen.getByText(/login/i)).toBeInTheDocument();
});
