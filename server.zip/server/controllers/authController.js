const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const User = require('../models/User');
const config = require('../config');

const tokens = new Set(); // A set to keep track of invalidated tokens

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findByUsername(username);

    if (!user) {
      return res.status(401).send({ error: 'Invalid username or password' });
    }

    const isMatch = await User.validatePassword(password, user.password);
    
    if (!isMatch) {
      return res.status(401).send({ error: 'Invalid username or password' });
    }

    const token = jwt.sign({ id: user.id }, config.jwtSecret, { expiresIn: '1h' });

    res.status(200).send({ token });
  } catch (error) {
    res.status(500).send({ error: 'An error occurred during login' });
  }
};

exports.logout = (req, res) => {
  const token = req.header('Authorization')?.replace('Bearer ', '');

  if (!token) {
    return res.status(400).send({ error: 'No token provided' });
  }

  try {
    tokens.add(token); // Add token to the set of invalidated tokens
    res.status(200).send({ message: 'Logout successful' });
  } catch (error) {
    res.status(500).send({ error: 'An error occurred during logout' });
  }
};
