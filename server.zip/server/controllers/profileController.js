const User = require('../models/User');

exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).send({ error: 'User not found' });
    }
    res.status(200).send(user);
  } catch (error) {
    res.status(500).send({ error: 'An error occurred while fetching profile' });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const { name, email, passportNumber } = req.body;
    const data = { name, email, passportNumber };
    await User.updateProfile(req.user.id, data);
    res.status(200).send({ message: 'Profile updated successfully' });
  } catch (error) {
    res.status(500).send({ error: 'An error occurred while updating profile' });
  }
};
