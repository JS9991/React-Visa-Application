import React from 'react';
import { useNavigate } from 'react-router-dom';

const Logout = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
   
    navigate('/login');
  };

  const handleCancel = () => {
    navigate('/');
  };

  return (
    <div className="logout-container">
      <h2>Confirm Logout</h2>
      <p>Are you sure you want to logout?</p>
      <div className="logout-buttons">
        <button onClick={handleLogout} className="logout-confirm">Yes, Logout</button>
        <button onClick={handleCancel} className="logout-cancel">Cancel</button>
      </div>
    </div>
  );
};

export default Logout;
