const express = require('express');
const applicationController = require('../controllers/applicationController');

const router = express.Router();

router.post('/', applicationController.submitApplication);

module.exports = router;
