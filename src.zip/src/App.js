import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './index.css';
import Header from './components/Header';
import Aside from './components/Aside';
import Footer from './components/Footer';
import Home from './components/Home';
import ProfilePage from './components/ProfilePage';
import Settings from './components/Settings';
import Logout from './components/Logout';
import Login from './components/Login';
import NewApplication from './components/NewApplication';
import Support from './components/Support';
import Eligibility from './components/Eligibility';

function App() {
  return (
    <Router>
      <div className="app">
        <Header />
        <div className="content">
          <Aside />
          <Routes>
          <Route path="/login" element={<Login/>} />
            <Route path="/" element={<Home />} />
            <Route path="/profile" element={<ProfilePage/>} />
            <Route path="/settings" element={<Settings/>} />
            <Route path="/logout" element={<Logout/>} />
            <Route path="/NewApplication" element={<NewApplication/>} />
            <Route path="/Support" element={<Support/>} />
            <Route path="/Eligibility" element={<Eligibility/>} />
          </Routes>
        </div>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
