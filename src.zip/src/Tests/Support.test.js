import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Support from '../components/Support';

describe('Support Page', () => {
    test('renders Support page with title and description', () => {
        render(<Support />);
        expect(screen.getByText('Support Page')).toBeInTheDocument();
        expect(screen.getByText('If you need help with your visa application, you can find answers to common questions below or contact us directly.')).toBeInTheDocument();
    });

    test('renders FAQ section with questions and answers', () => {
        render(<Support />);
        expect(screen.getByText('Frequently Asked Questions')).toBeInTheDocument();
        expect(screen.getByText('How do I apply for a visa?')).toBeInTheDocument();
        expect(screen.getByText('You can apply by filling out the online application form on our portal.')).toBeInTheDocument();
        expect(screen.getByText('What documents are required?')).toBeInTheDocument();
        expect(screen.getByText('You need to provide a valid passport, a recent photo, and any supporting documents based on your visa type.')).toBeInTheDocument();
    });

    test('renders Contact Form and handles input change and form submission', () => {
        render(<Support />);
        const nameInput = screen.getByLabelText('Name');
        const emailInput = screen.getByLabelText('Email');
        const messageTextarea = screen.getByLabelText('Message');
        const submitButton = screen.getByText('Submit');

        fireEvent.change(nameInput, { target: { value: 'John Doe' } });
        fireEvent.change(emailInput, { target: { value: 'johndoe@example.com' } });
        fireEvent.change(messageTextarea, { target: { value: 'I need help with my visa application.' } });

        expect(nameInput.value).toBe('John Doe');
        expect(emailInput.value).toBe('johndoe@example.com');
        expect(messageTextarea.value).toBe('I need help with my visa application.');

        fireEvent.click(submitButton);
        
        expect(screen.getByText('Support request submitted!')).toBeInTheDocument();
    });
});
