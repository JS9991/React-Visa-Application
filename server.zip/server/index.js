const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const dotenv = require('dotenv');
const sequelize = require('./db'); 
const profileRoutes = require('./routes/profile');
const applicationRoutes = require('./routes/application');
const settingsRoutes = require('./routes/settings');
const authRoutes = require('./routes/auth');


dotenv.config();

const app = express();
const port = process.env.PORT || 5000;


app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));


app.use('/api/profile', profileRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/application', applicationRoutes);
app.use('/api/auth', authRoutes);


sequelize.sync().then(() => {
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}).catch(err => {
  console.error('Unable to connect to the database:', err);
});
