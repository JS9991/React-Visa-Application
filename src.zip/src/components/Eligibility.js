import React from 'react';

const Eligibility = () => {
  return (
    <div className="eligibility-container">
      <main className="eligibility-main">
        <section className="eligibility-check-section">
          <h1>Check Your Visa Eligibility</h1>
          <p>Find out if you are eligible to apply for a visa.</p>
          <form id="eligibility-form" className="eligibility-form">
            <fieldset className="eligibility-fieldset">
              <legend>Personal Information</legend>
              <label htmlFor="full-name">Full Name:</label>
              <input type="text" id="full-name" name="full-name" required />

              <label htmlFor="dob">Date of Birth:</label>
              <input type="date" id="dob" name="dob" required />

              <label htmlFor="citizenship">Country of Citizenship:</label>
              <select id="citizenship" name="citizenship" required>
          
              </select>

              <label htmlFor="residence">Country of Destination:</label>
              <select id="residence" name="residence" required>
             
              </select>
            </fieldset>

            <fieldset className="eligibility-fieldset">
              <legend>Travel Information</legend>
              <label htmlFor="purpose">Purpose of Visit:</label>
              <select id="purpose" name="purpose" required>
              
              </select>

              <label htmlFor="duration">Intended Duration of Stay:</label>
              <input type="text" id="duration" name="duration" required />

              <label>Previous Visits in this country:</label>
              <input type="radio" id="previous-yes" name="previous-visits" value="yes" />
              <label htmlFor="previous-yes">Yes</label>
              <input type="radio" id="previous-no" name="previous-visits" value="no" />
              <label htmlFor="previous-no">No</label>
            </fieldset>

            <fieldset className="eligibility-fieldset">
              <legend>Additional Information</legend>
              <label>Criminal Record:</label>
              <input type="radio" id="criminal-yes" name="criminal-record" value="yes" />
              <label htmlFor="criminal-yes">Yes</label>
              <input type="radio" id="criminal-no" name="criminal-record" value="no" />
              <label htmlFor="criminal-no">No</label>

              <label>Medical Conditions:</label>
              <input type="radio" id="medical-yes" name="medical-conditions" value="yes" />
              <label htmlFor="medical-yes">Yes</label>
              <input type="radio" id="medical-no" name="medical-conditions" value="no" />
              <label htmlFor="medical-no">No</label>

              <label htmlFor="employment">Employment Status:</label>
              <select id="employment" name="employment" required>
             
              </select>

              <label htmlFor="income">Annual Income:</label>
              <input type="text" id="income" name="income" required />
            </fieldset>
            <button type="submit" className="eligibility-submit-btn">Check Eligibility</button>
          </form>
          <div id="results" className="eligibility-results">
       
          </div>
        </section>
      </main>


    </div>
  );
};

export default Eligibility;
