import React from 'react';
import { render, screen } from '@testing-library/react';
import Footer from '../components/Footer'; 

describe('Footer Component', () => {
  it('renders Privacy Policy, Terms of Service, and Contact Us links', () => {
    render(<Footer />);
    
    // Check that the links are rendered with the correct text
    expect(screen.getByText('Privacy Policy')).toBeInTheDocument();
    expect(screen.getByText('Terms of Service')).toBeInTheDocument();
    expect(screen.getByText('Contact Us')).toBeInTheDocument();
  });

  it('renders the social media div', () => {
    render(<Footer />);
    
    // Check that the social media div is rendered
    const socialMediaDiv = screen.getByRole('contentinfo').querySelector('.social-media');
    expect(socialMediaDiv).toBeInTheDocument();
  });
});
