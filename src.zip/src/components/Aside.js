import React from 'react';
import { Link } from 'react-router-dom';

function Aside() {
  return (
    <aside>
      <ul>
        <li><a href="/">Dashboard</a></li>
        <li><Link to ="/NewApplication">New Application</Link></li>
        <li><Link to="/settings">Settings</Link></li>
        <li><Link to="/Eligibility">Eligibility Checker</Link></li>
      </ul>
    </aside>
  );
}

export default Aside;
