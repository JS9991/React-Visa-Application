const db = require('../db');

class User {
  static async findByUsername(username) {
    const res = await db.query('SELECT * FROM users WHERE username = $1', [username]);
    return res.rows[0];
  }

  static async validatePassword(password, hashedPassword) {
    return bcrypt.compare(password, hashedPassword);
  }
  
  static async findById(id) {
    const res = await db.query('SELECT * FROM users WHERE id = $1', [id]);
    return res.rows[0];
  }

  static async updateProfile(id, data) {
    const { name, email, passportNumber } = data;
    await db.query(
      `UPDATE users 
       SET name = $1, email = $2, passport_number = $3 
       WHERE id = $4`,
      [name, email, passportNumber, id]
    );
  }

  static async updateSettings(id, settings) {
    const { email, password, notifications, profilePicture, language } = settings;
    await db.query(
      `UPDATE users 
       SET email = $1, password = $2, notifications = $3, profile_picture = $4, language = $5 
       WHERE id = $6`,
      [email, password, notifications, profilePicture, language, id]
    );
  }
}

module.exports = User;
