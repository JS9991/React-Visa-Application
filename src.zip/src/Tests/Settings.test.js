import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Settings from '../components/Settings'; 

describe('Settings Component', () => {
  test('renders Settings component correctly', () => {
    render(<Settings />);
    expect(screen.getByText('Settings')).toBeInTheDocument();
  });

  test('handles email input change', () => {
    render(<Settings />);
    const emailInput = screen.getByLabelText('Email:');
    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    expect(emailInput.value).toBe('test@example.com');
  });

  test('handles password input change', () => {
    render(<Settings />);
    const passwordInput = screen.getByLabelText('Password:');
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    expect(passwordInput.value).toBe('password123');
  });

  test('handles checkbox change', () => {
    render(<Settings />);
    const notificationsCheckbox = screen.getByLabelText('Enable Notifications:');
    fireEvent.click(notificationsCheckbox);
    expect(notificationsCheckbox.checked).toBe(false);
  });

  test('handles file upload', () => {
    render(<Settings />);
    const fileInput = screen.getByLabelText('Profile Picture:');
    const file = new File(['dummy content'], 'example.png', { type: 'image/png' });

    fireEvent.change(fileInput, { target: { files: [file] } });
    expect(fileInput.files[0]).toBe(file);
    expect(fileInput.files).toHaveLength(1);
  });

  test('handles language selection change', () => {
    render(<Settings />);
    const languageSelect = screen.getByLabelText('Language:');
    fireEvent.change(languageSelect, { target: { value: 'fr' } });
    expect(languageSelect.value).toBe('fr');
  });

  test('displays validation errors for invalid inputs', () => {
    render(<Settings />);
    const emailInput = screen.getByLabelText('Email:');
    const passwordInput = screen.getByLabelText('Password:');
    const submitButton = screen.getByText('Save Changes');

    fireEvent.change(emailInput, { target: { value: 'invalid-email' } });
    fireEvent.change(passwordInput, { target: { value: '123' } });
    fireEvent.click(submitButton);

    expect(screen.getByText('Please enter a valid email address.')).toBeInTheDocument();
    expect(screen.getByText('Password must be at least 6 characters long.')).toBeInTheDocument();
  });

  test('submits the form with valid inputs', async () => {
    global.fetch = jest.fn(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve({ message: 'Settings updated' }),
      })
    );

    render(<Settings />);
    const emailInput = screen.getByLabelText('Email:');
    const passwordInput = screen.getByLabelText('Password:');
    const submitButton = screen.getByText('Save Changes');

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    fireEvent.click(submitButton);

    expect(global.fetch).toHaveBeenCalledWith('/api/settings', expect.any(Object));

    global.fetch.mockClear();
  });
});
