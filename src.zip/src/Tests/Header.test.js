import React from 'react';
import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Header from '../components/Header'; 

describe('Header Component', () => {
  test('renders the logo text', () => {
    const { getByText } = render(
      <MemoryRouter>
        <Header />
      </MemoryRouter>
    );
    const logoElement = getByText(/Visa Application System/i);
    expect(logoElement).toBeInTheDocument();
  });

  test('renders the navigation links', () => {
    const { getByText } = render(
      <MemoryRouter>
        <Header />
      </MemoryRouter>
    );

    expect(getByText(/Home/i)).toBeInTheDocument();
    expect(getByText(/Profile/i)).toBeInTheDocument();
    expect(getByText(/Support/i)).toBeInTheDocument();
    expect(getByText(/Logout/i)).toBeInTheDocument();
  });

  test('checks if the links have correct href attributes', () => {
    const { getByText } = render(
      <MemoryRouter>
        <Header />
      </MemoryRouter>
    );

    expect(getByText(/Home/i).closest('a')).toHaveAttribute('href', '/');
    expect(getByText(/Profile/i).closest('a')).toHaveAttribute('href', '/profile');
    expect(getByText(/Support/i).closest('a')).toHaveAttribute('href', '/Support');
    expect(getByText(/Logout/i).closest('a')).toHaveAttribute('href', '/logout');
  });

  test('checks if the logout link has the correct class', () => {
    const { getByText } = render(
      <MemoryRouter>
        <Header />
      </MemoryRouter>
    );

    expect(getByText(/Logout/i)).toHaveClass('logout');
  });
});
