import React, { useState } from 'react';

const Settings = () => {
  const [settings, setSettings] = useState({
    email: '',
    password: '',
    notifications: true,
    profilePicture: null,
    language: 'en',
  });

  const [errors, setErrors] = useState({
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setSettings((prevSettings) => ({
      ...prevSettings,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleFileChange = (e) => {
    setSettings((prevSettings) => ({
      ...prevSettings,
      profilePicture: e.target.files[0],
    }));
  };

  const validate = () => {
    let valid = true;
    const newErrors = { email: '', password: '' };

    if (!settings.email.includes('@')) {
      newErrors.email = 'Please enter a valid email address.';
      valid = false;
    }

    if (settings.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters long.';
      valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validate()) {
      const formData = new FormData();
      formData.append('email', settings.email);
      formData.append('password', settings.password);
      formData.append('notifications', settings.notifications);
      formData.append('language', settings.language);

      if (settings.profilePicture) {
        formData.append('profilePicture', settings.profilePicture);
      }

      try {
        const response = await fetch('/api/settings', {
          method: 'POST',
          body: formData,
        });

        if (response.ok) {
          const result = await response.json();
          console.log('Settings updated:', result);
         
        } else {
          const error = await response.json();
          console.error('Error updating settings:', error);
    
        }
      } catch (error) {
        console.error('Network error:', error);
   
      }
    }
  };

  return (
    <div className="settings-page">
      <h1>Settings</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={settings.email}
            onChange={handleChange}
            required
          />
          {errors.email && <p className="error">{errors.email}</p>}
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            value={settings.password}
            onChange={handleChange}
            required
          />
          {errors.password && <p className="error">{errors.password}</p>}
        </div>
        <div className="form-group">
          <label htmlFor="notifications">Enable Notifications:</label>
          <input
            type="checkbox"
            id="notifications"
            name="notifications"
            checked={settings.notifications}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="profilePicture">Profile Picture:</label>
          <input
            type="file"
            id="profilePicture"
            name="profilePicture"
            accept="image/*"
            onChange={handleFileChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="language">Language:</label>
          <select
            id="language"
            name="language"
            value={settings.language}
            onChange={handleChange}
          >
            <option value="en">English</option>
            <option value="es">Spanish</option>
            <option value="fr">French</option>
         
          </select>
        </div>
        <button type="submit">Save Changes</button>
      </form>
    </div>
  );
};

export default Settings;
