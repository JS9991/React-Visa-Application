const Application = require('../models/Application');

exports.submitApplication = async (req, res) => {
  try {
    const application = await Application.create(req.body);
    res.status(201).send({
      message: 'Application submitted successfully',
      application,
    });
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: 'An error occurred while submitting the application' });
  }
};
