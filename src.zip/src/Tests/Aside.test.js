import React from 'react';
import { render } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import Aside from '../components/Aside';

describe('Aside Component', () => {
  test('renders correctly and contains all links', () => {
    const { getByText } = render(
      <Router>
        <Aside />
      </Router>
    );

    // Check if all links are present
    expect(getByText('Dashboard')).toBeInTheDocument();
    expect(getByText('New Application')).toBeInTheDocument();
    expect(getByText('Settings')).toBeInTheDocument();
    expect(getByText('Eligibility Checker')).toBeInTheDocument();

    // Check if links have correct href attributes
    expect(getByText('Dashboard').closest('a')).toHaveAttribute('href', '/');
    expect(getByText('New Application').closest('a')).toHaveAttribute('href', '/NewApplication');
    expect(getByText('Settings').closest('a')).toHaveAttribute('href', '/settings');
    expect(getByText('Eligibility Checker').closest('a')).toHaveAttribute('href', '/Eligibility');
  });
});
