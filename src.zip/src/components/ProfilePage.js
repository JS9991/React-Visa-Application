import React, { useState, useEffect } from 'react';
import axios from 'axios';

const fetchUserData = async () => {
  try {
    const response = await axios.get('/api/profile');
    return response.data;
  } catch (error) {
    console.error('Error fetching user data:', error);
    return {
      name: '',
      email: '',
      passportNumber: '',
      visaStatus: '',
    };
  }
};

const updateUserData = async (userData) => {
  try {
    const response = await axios.put('/api/profile', userData);
    return response.data;
  } catch (error) {
    console.error('Error updating user data:', error);
  }
};

const ProfilePage = () => {
  const [userData, setUserData] = useState({
    name: '',
    email: '',
    passportNumber: '',
    visaStatus: '',
  });

  useEffect(() => {
    const loadUserData = async () => {
      const data = await fetchUserData();
      setUserData(data);
    };

    loadUserData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const updatedData = await updateUserData(userData);
    if (updatedData) {
      setUserData(updatedData);
      console.log('User data updated:', updatedData);
    }
  };

  return (
    <div className="profile-page">
      <h1>User Profile</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            value={userData.name}
            onChange={handleInputChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={userData.email}
            onChange={handleInputChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="passportNumber">Passport Number:</label>
          <input
            type="text"
            id="passportNumber"
            name="passportNumber"
            value={userData.passportNumber}
            onChange={handleInputChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="visaStatus">Visa Status:</label>
          <input
            type="text"
            id="visaStatus"
            name="visaStatus"
            value={userData.visaStatus}
            onChange={handleInputChange}
            disabled
          />
        </div>

        <button type="submit">Update Profile</button>
      </form>
    </div>
  );
};

export default ProfilePage;
