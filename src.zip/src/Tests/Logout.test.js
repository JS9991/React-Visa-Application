import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter, useNavigate } from 'react-router-dom';
import Logout from '../components/Logout';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}));

describe('Logout Component', () => {
  it('renders the Logout component', () => {
    render(
      <MemoryRouter>
        <Logout />
      </MemoryRouter>
    );

    expect(screen.getByText('Confirm Logout')).toBeInTheDocument();
    expect(screen.getByText('Are you sure you want to logout?')).toBeInTheDocument();
    expect(screen.getByText('Yes, Logout')).toBeInTheDocument();
    expect(screen.getByText('Cancel')).toBeInTheDocument();
  });

  it('navigates to /login when Yes, Logout button is clicked', () => {
    const navigate = jest.fn();
    useNavigate.mockReturnValue(navigate);

    render(
      <MemoryRouter>
        <Logout />
      </MemoryRouter>
    );

    fireEvent.click(screen.getByText('Yes, Logout'));

    expect(navigate).toHaveBeenCalledWith('/login');
  });

  it('navigates to / when Cancel button is clicked', () => {
    const navigate = jest.fn();
    useNavigate.mockReturnValue(navigate);

    render(
      <MemoryRouter>
        <Logout />
      </MemoryRouter>
    );

    fireEvent.click(screen.getByText('Cancel'));

    expect(navigate).toHaveBeenCalledWith('/');
  });
});
