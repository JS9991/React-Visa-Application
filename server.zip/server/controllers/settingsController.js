const User = require('../models/User');

exports.updateSettings = async (req, res) => {
  try {
    const { email, password, notifications, language } = req.body;
    const profilePicture = req.file ? req.file.path : null;

    const settings = {
      email,
      password,
      notifications,
      profilePicture,
      language,
    };

    await User.updateSettings(req.user.id, settings);
    res.status(200).send({ message: 'Settings updated successfully' });
  } catch (error) {
    res.status(500).send({ error: 'An error occurred while updating settings' });
  }
};
