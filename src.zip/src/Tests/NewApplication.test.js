import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import NewApplication from '../components/NewApplication';

describe('NewApplication Component', () => {
  beforeEach(() => {
    global.fetch = jest.fn(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve({}),
      })
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('renders the NewApplication form with all fields', () => {
    render(<NewApplication />);

    expect(screen.getByLabelText(/Full Name/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Phone Number/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Passport Number/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Travel Date/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Purpose of Visit/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Submit Application/i })).toBeInTheDocument();
  });

  test('allows users to fill out the form and submit', async () => {
    render(<NewApplication />);

    fireEvent.change(screen.getByLabelText(/Full Name/i), { target: { value: 'John Doe' } });
    fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'john@example.com' } });
    fireEvent.change(screen.getByLabelText(/Phone Number/i), { target: { value: '1234567890' } });
    fireEvent.change(screen.getByLabelText(/Passport Number/i), { target: { value: 'A1234567' } });
    fireEvent.change(screen.getByLabelText(/Travel Date/i), { target: { value: '2024-08-15' } });
    fireEvent.change(screen.getByLabelText(/Purpose of Visit/i), { target: { value: 'Business' } });

    fireEvent.click(screen.getByRole('button', { name: /Submit Application/i }));

    expect(screen.getByText(/Submitting.../i)).toBeInTheDocument();

    await screen.findByText(/Application submitted successfully!/i);

    expect(global.fetch).toHaveBeenCalledWith('/api/applications', expect.objectContaining({
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        fullName: 'John Doe',
        email: 'john@example.com',
        phone: '1234567890',
        passportNumber: 'A1234567',
        travelDate: '2024-08-15',
        purposeOfVisit: 'Business',
      }),
    }));
  });

  test('displays an error message when the submission fails', async () => {
    global.fetch = jest.fn(() =>
      Promise.resolve({
        ok: false,
        json: () => Promise.resolve({ message: 'Invalid data' }),
      })
    );

    render(<NewApplication />);

    fireEvent.change(screen.getByLabelText(/Full Name/i), { target: { value: 'John Doe' } });
    fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'john@example.com' } });
    fireEvent.change(screen.getByLabelText(/Phone Number/i), { target: { value: '1234567890' } });
    fireEvent.change(screen.getByLabelText(/Passport Number/i), { target: { value: 'A1234567' } });
    fireEvent.change(screen.getByLabelText(/Travel Date/i), { target: { value: '2024-08-15' } });
    fireEvent.change(screen.getByLabelText(/Purpose of Visit/i), { target: { value: 'Business' } });

    fireEvent.click(screen.getByRole('button', { name: /Submit Application/i }));

    await screen.findByText(/Submission failed: Invalid data/i);
  });

  test('displays an error message when the fetch request fails', async () => {
    global.fetch = jest.fn(() => Promise.reject(new Error('Network error')));

    render(<NewApplication />);

    fireEvent.change(screen.getByLabelText(/Full Name/i), { target: { value: 'John Doe' } });
    fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'john@example.com' } });
    fireEvent.change(screen.getByLabelText(/Phone Number/i), { target: { value: '1234567890' } });
    fireEvent.change(screen.getByLabelText(/Passport Number/i), { target: { value: 'A1234567' } });
    fireEvent.change(screen.getByLabelText(/Travel Date/i), { target: { value: '2024-08-15' } });
    fireEvent.change(screen.getByLabelText(/Purpose of Visit/i), { target: { value: 'Business' } });

    fireEvent.click(screen.getByRole('button', { name: /Submit Application/i }));

    await screen.findByText(/An error occurred: Network error/i);
  });
});
