import React from 'react';

function Footer() {
  return (
    <footer>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
      <a href="#">Contact Us</a>
      <div className="social-media">
     
      </div>
    </footer>
  );
}

export default Footer;
