import React, { useState } from 'react';

const NewApplication = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    passportNumber: '',
    travelDate: '',
    purposeOfVisit: '',
  
  });

  const [status, setStatus] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('Submitting...');
    try {
      const response = await fetch('/api/applications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setStatus('Application submitted successfully!');

        setFormData({
          fullName: '',
          email: '',
          phone: '',
          passportNumber: '',
          travelDate: '',
          purposeOfVisit: '',
        });
      } else {
        const errorData = await response.json();
        setStatus(`Submission failed: ${errorData.message}`);
      }
    } catch (error) {
      setStatus(`An error occurred: ${error.message}`);
    }
  };

  return (
    <div className="new-application-page">
      <h1>New Visa Application</h1>
      <form onSubmit={handleSubmit} className="application-form">
        <div className="form-group">
          <label htmlFor="fullName">Full Name:</label>
          <input
            type="text"
            id="fullName"
            name="fullName"
            value={formData.fullName}
            onChange={handleChange}
            placeholder="Enter your full name"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Enter your email address"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Phone Number:</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="Enter your phone number"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="passportNumber">Passport Number:</label>
          <input
            type="text"
            id="passportNumber"
            name="passportNumber"
            value={formData.passportNumber}
            onChange={handleChange}
            placeholder="Enter your passport number"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="travelDate">Travel Date:</label>
          <input
            type="date"
            id="travelDate"
            name="travelDate"
            value={formData.travelDate}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="purposeOfVisit">Purpose of Visit:</label>
          <textarea
            id="purposeOfVisit"
            name="purposeOfVisit"
            value={formData.purposeOfVisit}
            onChange={handleChange}
            placeholder="Describe the purpose of your visit"
            required
          ></textarea>
        </div>
        <button type="submit" className="submit-button">Submit Application</button>
      </form>
      {status && <p>{status}</p>}
    </div>
  );
};

export default NewApplication;
