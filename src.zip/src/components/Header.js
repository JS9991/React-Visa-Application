import React from 'react';
import { Link } from 'react-router-dom';

function Header() {
  return (
    <header>
      <div className="logo">Visa Application System</div>
      <nav>
        <ul>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/profile">Profile</Link></li>
          <li><Link to="/Support">Support</Link></li>
          <li><Link to="/logout" className="logout">Logout</Link></li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
