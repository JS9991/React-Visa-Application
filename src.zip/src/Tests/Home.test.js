import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect'; 
import Home from '../components/Home';

describe('Home Component', () => {
  test('renders welcome message', () => {
    render(<Home />);
    const welcomeMessage = screen.getByText(/Welcome, \[Applicant Name\]!/i);
    expect(welcomeMessage).toBeInTheDocument();
  });

  test('renders summary cards', () => {
    render(<Home />);
    const submittedCard = screen.getByText(/Applications Submitted:/i);
    const progressCard = screen.getByText(/Applications in Progress:/i);
    const notificationsCard = screen.getByText(/Notifications:/i);
    expect(submittedCard).toBeInTheDocument();
    expect(progressCard).toBeInTheDocument();
    expect(notificationsCard).toBeInTheDocument();
  });

  test('renders quick action buttons', () => {
    render(<Home />);
    const startNewButton = screen.getByText(/Start New Application/i);
    const uploadDocsButton = screen.getByText(/Upload Documents/i);
    const checkStatusButton = screen.getByText(/Check Application Status/i);
    expect(startNewButton).toBeInTheDocument();
    expect(uploadDocsButton).toBeInTheDocument();
    expect(checkStatusButton).toBeInTheDocument();
  });

  test('renders application status overview', () => {
    render(<Home />);
    const statusOverview = screen.getByText(/Application Status Overview/i);
    const tableHeaderId = screen.getByText(/Application ID/i);
    const tableHeaderVisaType = screen.getByText(/Type of Visa/i);
    expect(statusOverview).toBeInTheDocument();
    expect(tableHeaderId).toBeInTheDocument();
    expect(tableHeaderVisaType).toBeInTheDocument();
  });

  test('renders notifications section', () => {
    render(<Home />);
    const notificationsHeading = screen.getByText(/Recent Notifications/i);
    expect(notificationsHeading).toBeInTheDocument();
  });

  test('renders profile summary', () => {
    render(<Home />);
    const profileName = screen.getByText(/Name: \[Applicant Name\]/i);
    const profileEmail = screen.getByText(/Email: \[Email\]/i);
    const profilePhone = screen.getByText(/Phone: \[Phone Number\]/i);
    expect(profileName).toBeInTheDocument();
    expect(profileEmail).toBeInTheDocument();
    expect(profilePhone).toBeInTheDocument();
  });
});
