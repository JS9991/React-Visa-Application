import React, { useState } from 'react';

const FAQ = () => {
    const faqs = [
        {
            question: "How do I apply for a visa?",
            answer: "You can apply by filling out the online application form on our portal."
        },
        {
            question: "What documents are required?",
            answer: "You need to provide a valid passport, a recent photo, and any supporting documents based on your visa type."
        },
      
    ];

    return (
        <div className="faq-container">
            <h2 className="faq-title">Frequently Asked Questions</h2>
            <ul className="faq-list">
                {faqs.map((faq, index) => (
                    <li key={index} className="faq-item">
                        <strong className="faq-question">{faq.question}</strong>
                        <p className="faq-answer">{faq.answer}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

const ContactForm = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        message: ''
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
       
        alert('Support request submitted!');
        setFormData({ name: '', email: '', message: '' });
    };

    return (
        <div className="contact-form-container">
            <h2 className="contact-form-title">Contact Us</h2>
            <form className="contact-form" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label className="form-label">Name</label>
                    <input 
                        type="text" 
                        name="name" 
                        className="form-input" 
                        value={formData.name} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <div className="form-group">
                    <label className="form-label">Email</label>
                    <input 
                        type="email" 
                        name="email" 
                        className="form-input" 
                        value={formData.email} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <div className="form-group">
                    <label className="form-label">Message</label>
                    <textarea 
                        name="message" 
                        className="form-textarea" 
                        value={formData.message} 
                        onChange={handleChange} 
                        required 
                    />
                </div>
                <button type="submit" className="form-submit-button">Submit</button>
            </form>
        </div>
    );
};

const Support = () => {
    return (
        <div className="support-page">
            <h1 className="support-title">Support Page</h1>
            <p className="support-description">
                If you need help with your visa application, you can find answers to common questions below or contact us directly.
            </p>
            <FAQ />
            <ContactForm />
        </div>
    );
};

export default Support;
